# PLOG 2020/2021 - TP1

## Group: Chess_Num_5
Turma 3

| Name             | Number    | E-Mail                |
| ---------------- | --------- | --------------------- |
| Pedro Varandas da Costa Azevedo da Ponte	   | 201809694 | up201809694@fe.up.pt  |
| Mariana Oliveira Ramos    | 201806869 | up201806869@fe.up.pt  |

---
## Installation and Execution

To correctly run and execute the puzzle, you just need to, using SICstus Prolog, define the working directory of SICStus in the game folder and use the instruction consult('chessnum.pl') ou ['chessnum.pl'], followed by the predicate start.

