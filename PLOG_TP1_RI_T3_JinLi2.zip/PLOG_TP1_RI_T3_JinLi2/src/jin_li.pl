:-consult('play.pl').
:-consult('display.pl').

jin_li :- 
	play.